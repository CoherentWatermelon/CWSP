package data.missions.CWSP_testmission;

import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;

public class MissionDefinition implements MissionDefinitionPlugin {

	public void defineMission(MissionDefinitionAPI api) {

		// Set up the fleets so we can add ships and fighter wings to them.
		// In this scenario, the fleets are attacking each other, but
		// in other scenarios, a fleet may be defending or trying to escape
		api.initFleet(FleetSide.PLAYER, "YSH", FleetGoal.ATTACK, false);	// Fleet goal can also be "FleetGoal.ESCAPE" for pursuit battles.
		api.initFleet(FleetSide.ENEMY, "ISS", FleetGoal.ATTACK, true);
		
		// Set a small blurb for each fleet that shows up on the mission detail and
		// mission results screens to identify each side.
		api.setFleetTagline(FleetSide.PLAYER, "Testing Craft");
		api.setFleetTagline(FleetSide.ENEMY, "An Atlas With Nothing To Lose");
		
		// These show up as items in the bulleted list under 
		// "Tactical Objectives" on the mission detail screen
		api.addBriefingItem("shoot bad guy");
		
		// Set up the player's fleet.  Variant names come from the
		// files in data/variants
		api.addToFleet(FleetSide.PLAYER, "CWSP_phorcys_pursuit", FleetMemberType.SHIP, "Phaser's Run", true);	// Player's flagship
		api.addToFleet(FleetSide.PLAYER, "CWSP_phorcys_screen", FleetMemberType.SHIP, "Overseer", false);	// A friendly ship (named)
		api.addToFleet(FleetSide.PLAYER, "CWSP_phorcys_beamer", FleetMemberType.SHIP, "Getting Heated", false);		// Another friendly ship (not named)
		api.addToFleet(FleetSide.PLAYER, "CWSP_aristaeus_strike", FleetMemberType.SHIP, "Sounds Like Bees In Here", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_aristaeus_pew", FleetMemberType.SHIP, "A Little Antimatter Never Hurt Anyone", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_hierophant_flag", FleetMemberType.SHIP, "Fireworks Show", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_hierophant_frontline", FleetMemberType.SHIP, "Love The Smell Of Plasma Scoring", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_hussar_reap", FleetMemberType.SHIP, "Red Light", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_hussar_what", FleetMemberType.SHIP, "Feels Like Bees In Here", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_respite_PD", FleetMemberType.SHIP, "No More Bees", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_respite_angery", FleetMemberType.SHIP, "A Little Antimatter Better Hurt Someone", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_october_atk", FleetMemberType.SHIP, "Seafloor Shindig", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_october_barrage", FleetMemberType.SHIP, "You Can Run", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_mule_phase_ion", FleetMemberType.SHIP, "Got My Ion You", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_mule_phase_insane", FleetMemberType.SHIP, "A Little Antimatter Oughtta Hurt You", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_mule_phase_p_arty", FleetMemberType.SHIP, "A Dream Of Distant Gunfire", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_mule_phase_p_assault", FleetMemberType.SHIP, "Don't Make Me Come Over There", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_red_october_atk", FleetMemberType.SHIP, "Rocket Surgery", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_red_october_strike", FleetMemberType.SHIP, "Do You Want To Explode?", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_backpack_PD", FleetMemberType.SHIP, "Pull!", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_backpack_strike", FleetMemberType.SHIP, "brrt", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_backpack_atk", FleetMemberType.SHIP, "Delivery", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_phorcys_x11_hvb", FleetMemberType.SHIP, "Tyrant", false);
		api.addToFleet(FleetSide.PLAYER, "heron_red", FleetMemberType.SHIP, "Stig's Retribution", false);
		api.addToFleet(FleetSide.PLAYER, "drover_CWSP_test", FleetMemberType.SHIP, "Drover For Scale", false);
		api.addToFleet(FleetSide.PLAYER, "drover_CWSP_test2", FleetMemberType.SHIP, "Drover For Scale", false);
		api.addToFleet(FleetSide.PLAYER, "astral_CWSP_test", FleetMemberType.SHIP, "Atlas For Scale", false);
		api.addToFleet(FleetSide.PLAYER, "condor_CWSP_test", FleetMemberType.SHIP, "Condor For Scale", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_illuminant_standard", FleetMemberType.SHIP, "Revenge of the Lobsters", false);
		api.addToFleet(FleetSide.PLAYER, "CWSP_hunter_regular", FleetMemberType.SHIP, "Lemme at Em", false);
		
		
		// Set up the enemy fleet.
		api.addToFleet(FleetSide.ENEMY, "atlas_Standard", FleetMemberType.SHIP, "Gee, Sure Is Quiet Around Here", false);		// Enemy ship
		
		api.defeatOnShipLoss("A Ship Name");	// The mission ends if the ship with this name dies. Can be friendly or enemy.
		
		// Set up the map.
		float width = 12000f;	// 1000 units = about one grid cell on the tactical map
		float height = 12000f;
		api.initMap((float)-width/2f, (float)width/2f, (float)-height/2f, (float)height/2f);
		
		float minX = -width/2;
		float minY = -height/2;
		
		// Add an asteroid field
		api.addAsteroidField(minX, minY + height / 2, 0, 8000f,
							 20f, 70f, 100);
		
		api.addPlanet(0, 0, 50f, StarTypes.RED_GIANT, 250f, true);
		
	}

}
